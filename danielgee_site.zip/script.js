
// Subtle entrance animation
document.addEventListener('DOMContentLoaded', function(){
  const cards = document.querySelectorAll('.card');
  cards.forEach((c, i)=>{
    c.style.opacity = 0;
    c.style.transform = 'translateY(8px)';
    setTimeout(()=>{
      c.style.transition = 'all 600ms cubic-bezier(.2,.8,.2,1)';
      c.style.opacity = 1;
      c.style.transform = 'translateY(0px)';
    }, 120 * i);
  });
});
