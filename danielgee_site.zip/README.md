
# Daniel Gee — Personal Site (GitHub Pages)

This repository contains a simple static website intended for GitHub Pages hosting.
It uses plain HTML/CSS/JS and is designed for a dark, fintech × Publius Marco aesthetic.

## Files included
- index.html
- style.css
- script.js
- assets/ (images)
- assets/Daniel_Gee_Resume.pdf (placeholder - replace with actual PDF file)

## Deploying to GitHub Pages
1. Make sure your repository is named `danielgee-pm.github.io` (it is).
2. Upload these files to the repository root (you can drag & drop in the web UI).
3. Commit and wait ~1-2 minutes. Your site will be available at:
   https://danielgee-pm.github.io
4. Replace `assets/Daniel_Gee_Resume.pdf` with your actual resume PDF (same filename), or update the link in `index.html`.

## Notes
- The site uses local images stored in `assets/img/`. You can replace them with your headshot or other images.
- Edit the content in `index.html` to update text, projects, and contact info.
